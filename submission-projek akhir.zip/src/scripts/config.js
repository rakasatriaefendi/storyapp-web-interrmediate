const CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1',
  DEFAULT_HEADER: {
    'Content-Type': 'application/json',
  },
};

export default CONFIG;
